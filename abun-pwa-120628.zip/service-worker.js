
const CACHE_NAME = 'bba-customer-service-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  '/dist/bundle.js', // <-- DITAMBAHKAN
  // Pastikan ikon utama untuk PWA juga ada di sini jika tidak ingin bergantung pada cache browser saja
  '/icons/icon-192x192.png', // Contoh ikon utama
  '/icons/icon-512x512.png', // Contoh ikon utama lainnya
  // Add other static assets like icons, main JS/CSS bundles if not CDN
  // 'https://picsum.photos/seed/bba_logo/150/50', // Ini placeholder, ganti dengan aset lokal jika ada
  // 'https://picsum.photos/seed/abun_default/80/80', // Placeholder
  // 'https://picsum.photos/seed/abun_sunda/80/80'  // Placeholder
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        // Menggunakan {cache: "reload"} untuk memastikan kita mendapatkan versi terbaru dari server saat instalasi,
        // terutama untuk sumber daya penting seperti bundle.js.
        const requests = urlsToCache.map(url => {
          // Untuk sumber daya lokal, kita bisa langsung cache.
          // Untuk CDN, default behavior (no explicit cache mode) biasanya cukup.
          // Jika ingin memastikan CDN juga fresh saat install, bisa tambahkan {cache: "reload"}
          // Namun, ini bisa memperlambat instalasi jika CDN lambat.
          // Untuk '/dist/bundle.js', karena ini krusial dan lokal, caching langsung OK.
          return new Request(url, url.startsWith('http') ? {} : {cache: "reload"});
        });
        return cache.addAll(requests);
      })
      .catch(error => {
        console.error('Gagal melakukan precache:', error);
        // Pertimbangkan untuk tidak menganggap instalasi gagal total jika beberapa aset non-kritis gagal di-cache.
        // Namun, jika bundle.js gagal, itu masalah.
      })
  );
});

self.addEventListener('fetch', event => {
  // Strategi: Network falling back to cache
  // Ini baik untuk konten yang sering update, tapi untuk aset inti PWA (app shell),
  // cache-first atau stale-while-revalidate mungkin lebih baik setelah instalasi awal.
  // Untuk kesederhanaan, kita pertahankan network-first.
  event.respondWith(
    fetch(event.request).then(
      networkResponse => {
        // Periksa apakah respons valid sebelum caching
        if(!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic' || event.request.method !== 'GET') {
          // Jangan cache POST request atau respons error atau respons opaque (misalnya dari CDN tanpa CORS yang benar untuk mode 'no-cors')
          // Khusus untuk 'basic' type, ini mencegah caching respons opaque dari CDN yang bisa jadi error pages.
          return networkResponse;
        }

        // Clone respons karena stream hanya bisa dibaca sekali
        const responseToCache = networkResponse.clone();

        caches.open(CACHE_NAME)
          .then(cache => {
            cache.put(event.request, responseToCache);
          });

        return networkResponse;
      }
    ).catch(() => {
      // Jika network gagal, coba ambil dari cache
      return caches.match(event.request)
        .then(cachedResponse => {
          if (cachedResponse) {
            return cachedResponse;
          }
          // Jika tidak ada di network dan tidak ada di cache, biarkan browser menangani (biasanya error offline)
          // Anda bisa menambahkan halaman offline kustom di sini jika mau.
          // return caches.match('/offline.html'); // Contoh halaman offline
          return new Response("Koneksi internet terputus dan halaman ini tidak ada di cache.", {
            status: 404,
            statusText: "Offline and not cached",
            headers: {'Content-Type': 'text/plain'}
          });
        });
    })
  );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
          return null;
        })
      );
    })
  );
});
